export function sendSuccess(res, data, message = "Success", statusCode = 200) {
  return res.status(statusCode).json({ success: true, message, data });
}

export default sendSuccess;
